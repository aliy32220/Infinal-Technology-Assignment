package com.example.ali.assignmentfinal;

import android.content.DialogInterface;
import android.graphics.Color;
import android.speech.RecognizerIntent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import android.content.Intent;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements OnInitListener{
    private TextToSpeech myTTS;//For text to Speech
    Button testbtn;//button to listen the text.
    Button speakbtn;//button to record.
    TextView MainText;// Main Body text
    TextView resulttext;// Result View
    TextView correctwords;//View for Correct Words
    TextView wrongwords;//View for Wrong Words
    ArrayList<String> Paragraph=new ArrayList<>();// Array list for main paragraph
    ArrayList<String> FINALRESULT=new ArrayList<>();//Array list for FINAL RESULT CHECKING
    String speak_paragraph;
    int correct_words=0; // #. of Correct Words
    int wrong_words=0;//#. of Wrong Words
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Paragraph.add("the quick brown fox jumps over the lazy dog");
        testbtn=(Button) findViewById(R.id.test_button);/////////////// Getting Ids.
        speakbtn=(Button) findViewById(R.id.Speak_button);
        MainText=(TextView) findViewById(R.id.Paragraph);
        resulttext=(TextView)findViewById(R.id.Result);
        correctwords=(TextView)findViewById(R.id.correctwords);
        wrongwords=(TextView)findViewById(R.id.wrongwords);
        Intent checkTTSIntent = new Intent();//Initializing the intent for TEXT to Speech.
        checkTTSIntent.setAction(TextToSpeech.Engine.ACTION_CHECK_TTS_DATA);
        startActivityForResult(checkTTSIntent, 0);
    }
    private void speakWords(String speech) { // Main function for application to Speak.
        //implement TTS here
        myTTS.speak(speech, TextToSpeech.QUEUE_FLUSH, null);
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {// Main on Activity result Function.
        if (requestCode == 0) {// '0' for tap to Listen the Paragrapgh Button.
            if (resultCode == TextToSpeech.Engine.CHECK_VOICE_DATA_PASS) {
                myTTS = new TextToSpeech(this, this);
            }
            else {
                Intent installTTSIntent = new Intent();
                installTTSIntent.setAction(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA);
                startActivity(installTTSIntent);
            }

        }
        else if (requestCode==1)//'1' for tap to Speak the paragraph Button.
        {
            if(resultCode==RESULT_OK && data!=null)
            {
                FINALRESULT.clear();/// Setting all to null.
                resulttext.setText(null);
                correct_words=0;
                wrong_words=0;
                ArrayList<String> result= data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String Spoken_Para= Arrays.toString(result.toArray()).replace("[","").replace("]","");
                String Spoken_Para1[]=Spoken_Para.split(" ");// Converting Array lists to String arrays.
                String paragraph= Arrays.toString(Paragraph.toArray()).replace("[","").replace("]","");
                String paragraph1[]=paragraph.split(" ");//Converting Array Lists to String Arrays.
                ArrayList<Integer> indexes= new ArrayList<Integer>();// An Arraylist to keep a count of index of wrong words
                int j=0;
                int size_p=paragraph1.length;// Size of Paragraph.
                int size_s=Spoken_Para1.length;//Size of Spoken Paragraph.
                for(int i=0; i<Spoken_Para1.length;i++) // Calculating the Wrong words and Correct Words
                {
                    if(j<paragraph1.length && j==0 ) {
                        if (Spoken_Para1[i].equalsIgnoreCase(paragraph1[j]) ||
                                Spoken_Para1[i].equalsIgnoreCase(paragraph1[j+1])) {
                            correct_words++;
                            j++;
                        } else {
                            wrong_words++;
                            indexes.add(Integer.valueOf(j));
                            j++;
                        }
                    }
                    else if (j<paragraph1.length && j>0 && j<paragraph1.length-1) {
                        if (Spoken_Para1[i].equalsIgnoreCase(paragraph1[j]) ||
                                Spoken_Para1[i].equalsIgnoreCase(paragraph1[j+1]) ||
                                    Spoken_Para1[i].equalsIgnoreCase(paragraph1[j-1])) {
                            correct_words++;
                            j++;
                        } else {
                            wrong_words++;
                            indexes.add(Integer.valueOf(j));
                            j++;
                        }
                    }
                    else if (j<paragraph1.length && j>0 && j==paragraph1.length-1) {
                        if (Spoken_Para1[i].equalsIgnoreCase(paragraph1[j])) {
                            correct_words++;
                            j++;
                        } else {
                            wrong_words++;
                            indexes.add(Integer.valueOf(j));
                            j++;
                        }
                    }
                    else
                    {
                        break;
                    }
                }
                //SHOWING and CALCULATING THE FINAL RESULT
                final int[] indx_arr = new int[indexes.size()];
                int index = 0;
                for (final Integer value: indexes) {
                    indx_arr[index++] = value;
                }
                if (size_s<size_p && wrong_words==0)
                {
                    j=0;
                    for(int i=0; i<size_p;i++)
                    {
                        if (Spoken_Para1[i].equalsIgnoreCase(paragraph1[j])) {
                            j++;
                        }
                        else {
                             FINALRESULT.add(Spoken_Para1[i]);
                             j++;
                        }
                    }
                }
                else if(size_s<size_p && wrong_words>1)
                {
                    for(int i=0; i<size_p;i++)
                    {
                        FINALRESULT.add(paragraph1[i]);
                    }
                }
                else if (size_s<size_p && wrong_words==1)
                {
                    FINALRESULT.add(paragraph1[indx_arr[0]+1]);
                }
                else if(size_s==size_p && wrong_words>0)
                {
                    for(int k=0;k<indx_arr.length;k++)
                    {
                        FINALRESULT.add(paragraph1[indx_arr[k]]);
                    }
                }
                correctwords.setText("Correct Words: " + String.valueOf(correct_words));// Displaying the #. of correct words.
                correctwords.setTextColor(Color.GREEN);
                correctwords.setAllCaps(true);
                wrongwords.setText("Wrong Words: "+ String.valueOf(wrong_words));// Displaying the #.of wrong words
                wrongwords.setTextColor(Color.RED);
                wrongwords.setAllCaps(true);
                String finalresult= Arrays.toString(FINALRESULT.toArray()).replace("[","").replace("]","");
                String finalresult1[]=finalresult.split(" ");//Concerting Arraylist to Array of string.
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
                alertDialogBuilder.setTitle("RESULT");
                alertDialogBuilder.setMessage("Correct Words: "+ correct_words + " Wrong Words:"+ wrong_words);
                alertDialogBuilder.setCancelable(true);//Showing the result on Dialog.

                alertDialogBuilder.setPositiveButton(
                        "Okay",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert11 = alertDialogBuilder.create();
                alert11.show();

                ForegroundColorSpan fcsRED= new ForegroundColorSpan(Color.RED); //Using the Foregroung Color Span.
                ForegroundColorSpan fcsGREEN= new ForegroundColorSpan(Color.GREEN);
                String s;
                for(int i=0;i<size_p;i++)
                {
                    int flag=0;
                    for(int l=0;l<finalresult1.length;l++)
                    {
                        if(paragraph1[i].equalsIgnoreCase(finalresult1[l]))
                        {
                            flag=1;
                        }
                    }
                    if(flag==1)
                    {
                        s=paragraph1[i];
                        SpannableString SS= new SpannableString(s); //Using Spannabble String to color results.
                        SS.setSpan(fcsRED,0, s.length()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        resulttext.append(SS+" ");
                    }
                    else
                    {
                        s=paragraph1[i];
                        SpannableString SS= new SpannableString(s);
                        SS.setSpan(fcsGREEN,0, s.length()-1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        resulttext.append(SS+" ");
                    }
                }

            }

        }
    }

    public void onClickTestButton(View v)// On clist Test/Listen Button.
    {
        speak_paragraph=String.valueOf(MainText.getText());
        speakWords(speak_paragraph);
    }

    public void onClickSpeakButton(View v){ //On click Tap to Speak Button.
        Intent intent =new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,Locale.US);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Hi! Speak Something");

        try{
            startActivityForResult(intent,1);
        }
        catch (Exception e)
        {
            Toast.makeText(this, "Your Device Don't Support Speech Input",Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onInit(int status) {//tts initializer.
        if (status == TextToSpeech.SUCCESS) {
            if(myTTS.isLanguageAvailable(Locale.US)==TextToSpeech.LANG_AVAILABLE) myTTS.setLanguage(Locale.US);
        }
        else if (status == TextToSpeech.ERROR) {
            Toast.makeText(this, "Sorry! Text To Speech failed...", Toast.LENGTH_LONG).show();
        }
    }

}
